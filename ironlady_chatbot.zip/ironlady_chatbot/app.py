from flask import Flask, render_template, request, jsonify
from faqs import get_faq_response
from ai import get_ai_response

app = Flask(__name__)
chat_history = []

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json["message"]
    chat_history.append(f"[{len(chat_history)+1}] User: {user_input}")

    faq_reply = get_faq_response(user_input)
    if faq_reply:
        bot_reply = faq_reply
    else:
        bot_reply = get_ai_response(user_input)

    chat_history.append(f"[{len(chat_history)+1}] Bot: {bot_reply}")
    return jsonify({"reply": bot_reply, "history": chat_history})

if __name__ == "__main__":
    app.run(debug=True)
