faq_data = {
    "programs": "Iron Lady offers leadership programs focused on confidence, strategy, and fast-track growth.",
    "duration": "Programs typically span a few weeks to a few months depending on the track.",
    "mode": "Most programs are delivered online for flexible access.",
    "certificates": "Yes, certificates are provided upon completion.",
    "mentors": "Mentors include global practitioners, entrepreneurs, and CXOs like Rajesh Bhat."
}

def get_faq_response(user_input):
    for key in faq_data:
        if key in user_input.lower():
            return faq_data[key]
    return None
